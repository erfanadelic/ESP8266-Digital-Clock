#include "EBigNum.h"
byte leftSide[8] = 
{
  B00111,
  B01111,
  B01111,
  B01111,
  B01111,
  B01111,
  B01111,
  B00111
};
byte upperBar[8] =
{
  B11111,
  B11111,
  B11111,
  B00000,
  B00000,
  B00000,
  B00000,
  B00000
};
byte rightSide[8] =
{
  B11100,
  B11110,
  B11110,
  B11110,
  B11110,
  B11110,
  B11110,
  B11100
};
byte leftEnd[8] =
{
  B01111,
  B00111,
  B00000,
  B00000,
  B00000,
  B00000,
  B00011,
  B00111
};
byte lowerBar[8] =
{
  B00000,
  B00000,
  B00000,
  B00000,
  B00000,
  B11111,
  B11111,
  B11111
};
byte rightEnd[8] =
{
  B11110,
  B11100,
  B00000,
  B00000,
  B00000,
  B00000,
  B11000,
  B11100
};
byte middleBar[8] =
{
  B11111,
  B11111,
  B11111,
  B00000,
  B00000,
  B00000,
  B11111,
  B11111
};
byte lowerEnd[8] = 
{
  B00000,
  B00000,
  B00000,
  B00000,
  B00000,
  B00000,
  B00111,
  B01111
};
EBigNum::EBigNum(LiquidCrystal_I2C* lcd)
{
  _lcd = lcd;
}
void EBigNum::begin()
{
  // create custom characters
  _lcd->createChar(0, leftSide);
  _lcd->createChar(1, upperBar);
  _lcd->createChar(2, rightSide);
  _lcd->createChar(3, leftEnd);
  _lcd->createChar(4, lowerBar);
  _lcd->createChar(5, rightEnd);
  _lcd->createChar(6, middleBar);
  _lcd->createChar(7, lowerEnd);
}

void EBigNum::print(byte Num, byte C) // n is number to display, C is column of upper left corner for large character
{
  switch (Num)
  {
    case 0:
    {
      _lcd->setCursor(C,0);
      _lcd->write(byte(0));
      _lcd->write(1);
      _lcd->write(2);
      _lcd->setCursor(C, 1);
      _lcd->write(byte(0));
      _lcd->write(4);
      _lcd->write(2);
      break;
    }
    case 1:
    {
      _lcd->setCursor(C,0);
      _lcd->write(char(254));
      _lcd->write(char(254));
      _lcd->write(2);
      _lcd->setCursor(C,1);
      _lcd->write(char(254));
      _lcd->write(char(254));
      _lcd->write(2);
      break;
    }
    case 2:
    {
      _lcd->setCursor(C,0);
      _lcd->write(3);
      _lcd->write(6);
      _lcd->write(2);
      _lcd->setCursor(C, 1);
      _lcd->write(byte(0));
      _lcd->write(4);
      _lcd->write(4);
      break;
    }
    case 3:
    {
      _lcd->setCursor(C,0);
      _lcd->write(3);
      _lcd->write(6);
      _lcd->write(2);
      _lcd->setCursor(C, 1);
      _lcd->write(7);
      _lcd->write(4);
      _lcd->write(2);
      break;
    }
    case 4:
    {
      _lcd->setCursor(C,0);
      _lcd->write(byte(0));
      _lcd->write(4);
      _lcd->write(2);
      _lcd->setCursor(C, 1);
      _lcd->write(char(254));
      _lcd->write(char(254));
      _lcd->write(2);
      break;
    }
    case 5:
    {
      _lcd->setCursor(C,0);
      _lcd->write(byte(0));
      _lcd->write(6);
      _lcd->write(5);
      _lcd->setCursor(C, 1);
      _lcd->write(7);
      _lcd->write(4);
      _lcd->write(2);
      break;
    }
    case 6:
    {
      _lcd->setCursor(C,0);
      _lcd->write(byte(0));
      _lcd->write(6);
      _lcd->write(5);
      _lcd->setCursor(C, 1);

      _lcd->write(4);
      _lcd->write(2);
      break;
    }
    case 7:
    {
      _lcd->setCursor(C,0);
      _lcd->write(1);
      _lcd->write(1);
      _lcd->write(2);
      _lcd->setCursor(C, 1);
      _lcd->write(char(254));
      _lcd->write(char(254));
      _lcd->write(2);
      break;
    }
    case 8:
    {
      _lcd->setCursor(C,0);
      _lcd->write(byte(0));
      _lcd->write(6);
      _lcd->write(2);
      _lcd->setCursor(C, 1);
      _lcd->write(byte(0));
      _lcd->write(4);
      _lcd->write(2);
      break;
    }
    case 9:
    {
      _lcd->setCursor(C,0);
      _lcd->write(byte(0));
      _lcd->write(6);
      _lcd->write(2);
      _lcd->setCursor(C, 1);
      _lcd->write(7);
      _lcd->write(4);
      _lcd->write(2);
      break;
    }
  }
}