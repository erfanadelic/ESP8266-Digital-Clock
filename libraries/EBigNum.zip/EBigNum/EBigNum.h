#ifndef EBigNum_h
#define EBigNum_h

#include "Arduino.h"
#include "LiquidCrystal_I2C.h"

class EBigNum{
    public:
        EBigNum(LiquidCrystal_I2C*);
        void begin();
        void print(byte,byte);
    private:
        LiquidCrystal_I2C* _lcd;
};

#endif
//ardino lib